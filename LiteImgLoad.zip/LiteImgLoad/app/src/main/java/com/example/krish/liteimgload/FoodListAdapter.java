package com.example.krish.liteimgload;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class FoodListAdapter extends BaseAdapter {

    private Context context;
    private int layout;
    private ArrayList<Food> foodslist;

    public FoodListAdapter(Context context, int layout, ArrayList<Food> foodslist) {
        this.context = context;
        this.layout = layout;
        this.foodslist = foodslist;
    }

    @Override
    public int getCount() {
        return foodslist.size();
    }

    @Override
    public Object getItem(int position) {
        return foodslist.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class ViewHolder{
        ImageView imageV;
        TextView txtname,txtprice;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {

       View  row = view;
       ViewHolder holder = new ViewHolder();
       if(row == null){
           LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
           row = inflater.inflate(layout,null);

           holder.txtname = (TextView)row.findViewById(R.id.txtname);
           holder.txtprice = (TextView)row.findViewById(R.id.txtprice);
           holder.imageV = (ImageView)row.findViewById(R.id.imgfood);
           row.setTag(holder);
       }
       else{
           holder = (ViewHolder) row.getTag();
       }

       Food food = foodslist.get(position);

       holder.txtname.setText(food.getName());
       holder.txtprice.setText(food.getPrice());

       byte[] foodimage = food.getImage();
        Bitmap bitmap = BitmapFactory.decodeByteArray(foodimage,0,foodimage.length);

        holder.imageV.setImageBitmap(bitmap);

        return row;
    }
}
